[Greg Makasoff], [A00959883], [Set B], [January 23, 2019]

This assignment is [100]% complete.


------------------------
GUI status

[complete]
------------------------
ConsoleUI status

[complete]
------------------------

I did not require any outside sources to complete this assignment.