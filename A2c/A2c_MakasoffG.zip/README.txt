[Greg Makasoff], [A00959883], [Set B], [January 23, 2019]

This assignment is [70]% complete.


------------------------
Bishop status

[complete]
------------------------
Board status

[complete]
------------------------
EventListener status

[complete]
------------------------
Game status

[complete]
------------------------
King status

[complete]
------------------------
Knight status

[complete]
------------------------
Pawn status

[complete]
------------------------
Piece status

[complete]
------------------------
Player status

[complete]
------------------------
Queen status

[complete]
------------------------
Rook status

[complete]
------------------------
Square status

[complete]
------------------------
Save / Load

[incomplete]
------------------------

I had help from stack overflow.